import { Component, OnInit, Input } from '@angular/core';
import { EmployeeModel } from '../../models/employee-model';
import { CreateEmployeeService } from '../../services/create-employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  id: number; 
  username: String;
  phone: number;
  role: String;
  name: String;
  
  employees: EmployeeModel[];

  employeeService: CreateEmployeeService = new CreateEmployeeService();

  constructor() { 
    if(this.employeeService.checkExists()){
      this.employees = this.employeeService.getEmployees();
      this.id = this.employees[this.employees.length-1].id + 1;
    }
    else{
      this.id = 1;
    }
  }

  ngOnInit() {

  }

  public clearErrors(input: HTMLInputElement): void{
    var id = input.getAttribute("id");
    document.getElementById(id).classList.remove("is-invalid");
  }

  public showAddNewForm(): void{
    document.getElementById("addEmployeeHeader").style.display = "none";
    document.getElementById("addNewForm").style.display = "block";
  }

  public addEmployee(username: HTMLInputElement, phone: HTMLInputElement, 
    role: HTMLSelectElement, firstname: HTMLInputElement, lastname: HTMLInputElement): void{
    if(username.value != '' && phone.value != '' && role.options[role.selectedIndex].value != '' && firstname.value != '' && lastname.value != ''){
      // Check phone number duplicate or not
      let flag: boolean = true;
      this.employeeService.getPhoneNumbers().forEach(element=> {
        if(element == parseInt(phone.value)){
          document.getElementById("phone").classList.add("is-invalid");
          flag=false;
        }
      });

      // Check username regex validity
      var userStr = username.value;
      var regX = /^[\w-_]+$/;
      if(!regX.test(userStr)){
        document.getElementById("username").classList.add("is-invalid");
        flag = false;
      }

      if(flag == true){
        this.employeeService.addEmployee(username.value, parseInt(phone.value), role.value, firstname.value, lastname.value);
        
        // Clearing fields
        username.value = "";
        phone.value = "";
        role.selectedIndex = 0;
        firstname.value = "";
        lastname.value = "";

        document.getElementById("addNewForm").style.display = "none";
        document.getElementById("confirmation").style.display = "block";     
        
        // Refresh list
        this.employees = this.employeeService.getEmployees();

        // Refreshing ID
        if(this.employeeService.checkExists()){
          this.employees = this.employeeService.getEmployees();
          this.id = this.employees[this.employees.length-1].id + 1;
        }
        else{
          this.id = 1;
        }

        setTimeout(function () {
          document.getElementById("addEmployeeHeader").style.display = "block";
          document.getElementById("confirmation").style.display = "none";             
        }, 2000);
      }
      
    }
    else{
      alert("All fields are required.");
    }
    console.log(`Entries are : ${username.value} and ${phone.value} and ${role.options[role.selectedIndex].value} and ${firstname.value} + ${lastname.value}`);
  }

  public removeEmployee(empid: number, element: HTMLElement): void{
    if(this.employeeService.removeEmployee(empid) === 1){
      alert('Employee Deleted');
      this.employees = this.employeeService.getEmployees();
      this.id = this.employees[this.employees.length-1].id + 1;            
    }    
  }

}
