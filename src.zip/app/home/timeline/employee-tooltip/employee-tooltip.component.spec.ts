import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeTooltipComponent } from './employee-tooltip.component';

describe('EmployeeTooltipComponent', () => {
  let component: EmployeeTooltipComponent;
  let fixture: ComponentFixture<EmployeeTooltipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeTooltipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeTooltipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
