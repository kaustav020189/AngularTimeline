import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-tooltip',
  templateUrl: './employee-tooltip.component.html',
  styleUrls: ['./employee-tooltip.component.css']
})
export class EmployeeTooltipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
