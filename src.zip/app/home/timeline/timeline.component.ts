import { Component, OnInit, Input } from '@angular/core';
import { PostcontentService } from '../../services/postcontent.service';
import { PostModel } from '../../models/post-model';
import { UrlHandlingStrategy } from '@angular/router';
import { CreateEmployeeService } from '../../services/create-employee.service';
import { EmployeeModel } from '../../models/employee-model';
import { element } from 'protractor';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.css']
})
export class TimelineComponent implements OnInit {

  private posts: PostModel[];

  private id: number;
  private postOwner: String;
  private pic: String;
  private time: number;
  private postContent: String;

  private postService: PostcontentService = new PostcontentService();

  private employees: EmployeeModel[];
  private employeeService: CreateEmployeeService = new CreateEmployeeService();

  private elements: NodeListOf<Element>;

  constructor() {
    if(this.postService.checkExists()){
      this.posts = this.postService.getPosts().sort(
        function(a, b) {
           return b.time.valueOf() - a.time.valueOf();   // Sorting in descending order
        });
      this.id = this.posts[0].id + 1;
    }
    else{
      this.id = 1;
    }        
    
    // Get employees
    this.employees =  this.employeeService.getEmployees();
  }

  ngOnInit() {
  }

  ngAfterViewInit(){
    // $('.post-content').each(function(){
    //   alert('hi')
    // })

   /* Array.from(document.getElementsByClassName('post-content')).forEach(function(element) {
      // text inside Element, is considered as text node. So, childnode[0] means text.
      let elementText: string = element.childNodes[0].nodeValue;    
      element.innerHTML = elementText;
    });*/
   
  }

  private addPost(localowner: HTMLInputElement, localcontent: HTMLTextAreaElement): void{
    let postService = new PostcontentService();
    this.pic = "../../../assets/images/img1.png"; 
    this.time = (new Date()).valueOf();
    // Editing content part to check for employee links
    let words: String[] = this.postContent.split(' ');
    let strToBeSaved: String = "";
    words.forEach(element=>{
      if(element.charAt(0) == '@'){
        // element = element.substring(1,element.length-1);
        // strToBeSaved = strToBeSaved + " <a href=\"#\">" + element + "<app-employee-tooltip id=\"\ " + element + " \"></app-employee-tooltip></a> ";
        strToBeSaved = strToBeSaved + " " + element;
      }
      else{
        strToBeSaved = strToBeSaved + " " + element;
      }
    });
    postService.addPost(this.id, this.time, this.postOwner, this.pic, strToBeSaved);
    this.posts = postService.getPosts().sort(
      function(a, b) {
         return b.time.valueOf() - a.time.valueOf();   // Sorting in descending order
      });

    this.id = this.posts[0].id + 1;

    localowner.value = "";
    localcontent.value = "";
  }

  private removePost(postId: number): void{
    let postService: PostcontentService = new PostcontentService();
    if(postService.removePost(postId) === 1){
      alert('Post Deleted');
      this.posts = postService.getPosts().sort(
        function(a, b) {
           return b.time.valueOf() - a.time.valueOf();   // Sorting in descending order
        });
      this.id = this.posts[0].id + 1;        
    }
  }

  public checkForAtTheRate(event:KeyboardEvent): void{
    if(event.key == '@'){
      document.getElementById("postSection").style.display = "block";
    }
    else{
      document.getElementById("postSection").style.display = "none";
    }
  }

  public appendUser(username: String, name: String){
    document.getElementById("postSection").style.display = "none";
    let textAreaElement: HTMLTextAreaElement = <HTMLTextAreaElement>document.getElementById("postInput");
    textAreaElement.value = textAreaElement.value + username;
    this.postContent = textAreaElement.value;
    textAreaElement.focus();
  }
  

}
