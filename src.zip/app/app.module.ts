import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AddEmployeeComponent } from './home/add-employee/add-employee.component';
import { AppRoutingModule } from './app-routing.module';
import { TimelineComponent } from './home/timeline/timeline.component';
import { PostcontentService } from './services/postcontent.service';
import { CreateEmployeeService } from './services/create-employee.service';

import { FormsModule } from '@angular/forms';
import { EmployeeTooltipComponent } from '../app/home/timeline/employee-tooltip/employee-tooltip.component';
import * as $ from 'jquery';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AddEmployeeComponent,
    TimelineComponent,
    EmployeeTooltipComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
  ],
  providers: [
    PostcontentService,
    CreateEmployeeService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
