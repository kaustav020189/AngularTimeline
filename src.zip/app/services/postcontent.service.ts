import { Injectable } from '@angular/core';
import { PostModel } from '../models/post-model';

@Injectable({
  providedIn: 'root'
})
export class PostcontentService {
  
  constructor() { }

  public checkExists(): boolean{
    if(localStorage.getItem('posts') === null){
      return false;
    }
    else{
      return true;
    }
  }

  public getPosts(): PostModel[] {
    let localStorageItem = JSON.parse(localStorage.getItem('posts'));
    return localStorageItem == null ? [] : localStorageItem.posts;
  }

  public addtoStorage(posts: PostModel[]): void {
    localStorage.setItem('posts', JSON.stringify({posts : posts}))
  }

  public addPost(id: number, time: number, owner: String, pic: String, content: String): void{
    const monthNames = ["January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    
    let d = new Date();
    let dateInString: String; 
    dateInString = ('0' + d.getHours()).slice(-2) + ":" + ('0' + d.getMinutes()).slice(-2)+" | "+(monthNames[d.getMonth()])+" "+d.getDate()+", "+d.getFullYear();
    let post = new PostModel(id, time, dateInString, owner, pic, content);
    let posts = this.getPosts();
    posts.push(post);

    this.addtoStorage(posts);
  }

  public removePost(postId: number): number{
    if(localStorage.getItem('posts') === null){
      return -1;
    }
    else{
      let posts: PostModel[] = this.getPosts();
      let length: number = posts.length;
      posts.forEach(function(p, index) {
        if(p.id == postId){
          posts.splice(index, 1);
          if(length != 1){  
            localStorage.setItem('posts', JSON.stringify({posts : posts}));
          }
          else{   // If this is the last post
            localStorage.removeItem('posts');
          }                    
        }
      });      
      return 1;
    }
  }
}
