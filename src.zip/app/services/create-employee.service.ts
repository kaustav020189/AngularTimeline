import { Injectable } from '@angular/core';
import { EmployeeModel } from './../models/employee-model';
import { last } from '@angular/router/src/utils/collection';
import { element } from '@angular/core/src/render3/instructions';

@Injectable({
  providedIn: 'root'
})
export class CreateEmployeeService {

  constructor() { }

  public getEmployees(): EmployeeModel[]{
    let localStorageItem = JSON.parse(localStorage.getItem('employee'));
    return localStorageItem == null ? [] : localStorageItem.employee;
  }

  public addtoStorage(employee: EmployeeModel[]): void {
    localStorage.setItem('employee', JSON.stringify({employee : employee}))
  }

  public addEmployee(username: String, phone: number, role: String, firstname: String, lastname: String): void{
    let id: number = 1;
    if(this.checkExists()){
      id = this.getEmployees()[this.getEmployees().length - 1].id + 1;
    }
    let name: String = firstname + ' ' + lastname;
    let employee = new EmployeeModel(id, username, phone, role, name);
    let employees = this.getEmployees();
    employees.push(employee);

    this.addtoStorage(employees);    
  }

  public checkExists(): boolean{
    if(localStorage.getItem('employee') === null){
      return false;
    }
    else{
      return true;
    }
  }

  public getPhoneNumbers(): number[]{
    let phoneNumbers: number[] = [];
    if(localStorage.getItem('employee') !== null){
      this.getEmployees().forEach(element => {
        phoneNumbers.push(element.phone);
      });
    }
    return phoneNumbers;
  }

  public removeEmployee(id: number): number{
    if(localStorage.getItem('employee') === null){
      return -1;
    }
    else{
      let employees: EmployeeModel[] = this.getEmployees();
      let length: number = employees.length;
      employees.forEach(function(emp, index) {
        if(emp.id == id){
          employees.splice(index, 1);
          if(length != 1){  
            localStorage.setItem('employee', JSON.stringify({employee : employees}));
          }
          else{   // If this is the last employee
            localStorage.removeItem('employee');
          }                    
        }
      });      
      return 1;
    }
  }

}
