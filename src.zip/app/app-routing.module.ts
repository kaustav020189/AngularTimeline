import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TimelineComponent } from '../app/home/timeline/timeline.component';
import { AddEmployeeComponent } from '../app/home/add-employee/add-employee.component';

const routes: Routes = [
  // { path: '', redirectTo: '/', pathMatch: 'full' },
  { path: '', component: TimelineComponent },
  { path: 'admin', component: AddEmployeeComponent }
];

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forRoot(routes)]
})
export class AppRoutingModule { }
