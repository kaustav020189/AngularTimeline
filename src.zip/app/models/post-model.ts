export class PostModel {
    id: number;
    time: number;
    timeForDisplay: String;
    owner: String;
    pic: String;
    content: String

    constructor(id: number, time: number, timeForDisplay: String, owner: String, pic: String, content: String){
        this.id = id;
        this.time = time;
        this.timeForDisplay = timeForDisplay;
        this.owner = owner;
        this.pic = pic;
        this.content = content;
    }
}
