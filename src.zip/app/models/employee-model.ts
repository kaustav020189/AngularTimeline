export class EmployeeModel {
    id: number;
    username: String;
    phone: number;
    role: String;
    name: String

    constructor(id: number, username: String, phone: number, role: String, name: String){
        this.id = id;
        this.username = username;
        this.phone = phone;
        this.role = role;
        this.name = name;
    }
}
